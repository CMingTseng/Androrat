/** Automatically generated file. DO NOT MODIFY */
package my.app.client;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}